package com.eduardo.prueba.springboot.webapp.springboot_web.controllers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eduardo.prueba.springboot.webapp.springboot_web.models.Usuario;

@RestController
@RequestMapping("/api")
public class UserRestController {

    @GetMapping("/details")
    public Map<String, Object>details(){

        Usuario usuario = new Usuario("Eduardo", "Baeza", "eduardob@gmail.com");
        Map<String, Object> body = new HashMap<>();

        body.put("mensaje", "Hola Mundo!! - SpringBoot");
        body.put("usuario", usuario);

        return body;
    }


}
