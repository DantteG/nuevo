package com.dantte_011d.springboot.crud.springboot_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
