package com.dantte_011d.springboot.crud.springboot_crud.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dantte_011d.springboot.crud.springboot_crud.entities.producto;
import com.dantte_011d.springboot.crud.springboot_crud.entities.producto;
import com.dantte_011d.springboot.crud.springboot_crud.services.ProductService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;




@RestController
@RequestMapping("api/productos")
public class ProductController {

    @Autowired
    private ProductService service;
    
    @GetMapping List<producto> List(){
        return service.findbyAll();
    }
    
    @GetMapping("/{id}")
public ResponseEntity<?> verDetalle(@PathVariable Long id){
    Optional<producto> producOptional = service.findById(id);
    if (producOptional.isPresent()) {
        return ResponseEntity.ok(producOptional.orElseThrow());
    }
    return ResponseEntity.notFound().build();
}
    
    @PostMapping
    public ResponseEntity<producto> crear (@RequestBody producto unProducto){
        return ResponseEntity.status(HttpStatus.CREATED).body(service.save(unProducto));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<?> modificar(@PathVariable Long id, @RequestBody producto unProducto){
        Optional <producto> productoOptional = service.findById(id);
        if (productoOptional.isPresent()) {
            producto productoexistente = productoOptional.get();
            productoexistente.setNombre(unProducto.getNombre());
            productoexistente.setDescripcion(unProducto.getDescripcion());
            productoexistente.setPrecio(unProducto.getPrecio());
            producto productomodificado = service.save(productoexistente);
            return ResponseEntity.ok(productomodificado);
        }
        return ResponseEntity.notFound().build();
    }
    
    @DeleteMapping("{/id}")
    public ResponseEntity<?> eliminar (@PathVariable Long id){
        producto unProducto = new producto();
        unProducto.setId(id);
        Optional<producto> productoOptional = service.delete(unProducto);
        if (productoOptional.isPresent()) {
            return ResponseEntity.ok(productoOptional.orElseThrow());
        }
        return ResponseEntity.noContent().build();
    }

}
