package com.dantte_011d.springboot.crud.springboot_crud.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.dantte_011d.springboot.crud.springboot_crud.entities.producto;
import com.dantte_011d.springboot.crud.springboot_crud.repository.ProductoRepository;

import org.springframework.transaction.annotation.Transactional;

public class ProductServiceImpl implements ProductService{

    @Autowired
    private ProductoRepository repository;
    @Override
    @Transactional
    public Optional<producto> delete(producto unProducto) {
        Optional<producto> productoOptional = repository.findById(unProducto.getId());
        productoOptional.ifPresent(productoDb ->{
        repository.delete(unProducto);
        });
        return productoOptional;
    }

    @Override
    @Transactional (readOnly = true)
    public Optional<producto> findById(Long Id) {
        return repository.findById(Id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<producto> findbyAll() {
        return (List<producto>) repository.findAll() ;
    }

    @Override
    @Transactional
    public producto save(producto unProducto) {
        return repository.save(unProducto);
    }

    

}
