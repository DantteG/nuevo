package com.dantte_011d.springboot.crud.springboot_crud.services;

import java.util.List;
import java.util.Optional;

import com.dantte_011d.springboot.crud.springboot_crud.entities.producto;

public interface ProductService {

    List<producto> findbyAll();

    Optional<producto> findById (Long Id);

    producto save (producto unProducto);

    Optional <producto> delete (producto unProducto);
}
