package com.dantte_011d.springboot.crud.springboot_crud.repository;

import org.springframework.data.repository.CrudRepository;

import com.dantte_011d.springboot.crud.springboot_crud.entities.producto;

public interface ProductoRepository extends CrudRepository<producto, Long>{



}
