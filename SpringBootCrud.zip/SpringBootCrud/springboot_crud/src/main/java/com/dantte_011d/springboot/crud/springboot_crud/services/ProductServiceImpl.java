package com.dantte_011d.springboot.crud.springboot_crud.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.dantte_011d.springboot.crud.springboot_crud.entities.producto;
import com.dantte_011d.springboot.crud.springboot_crud.repository.ProductoRepository;

import org.springframework.transaction.annotation.Transactional;

public class ProductServiceImpl implements ProductService{

    @Autowired
    private ProductoRepository repository;
    @Override
    
    public Optional<producto> delete(producto unProducto) {

        return null;
    }

    @Override
    public Optional<producto> findById(Long Id) {
        // TODO Auto-generated method stub
        return Optional.empty();
    }

    @Override
    @Transactional(readOnly = true)
    public List<producto> findbyAll() {
        return (List<producto>) repository.findAll() ;
    }

    @Override
    public producto save(producto unProducto) {
        // TODO Auto-generated method stub
        return null;
    }

    

}
