package com.dantte_011d.springboot.jpa.demo;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class person {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long ID;


    private String nombre;
    private String Apellido;

    @Column(name = "Lenguajes_programacion")
    private String LenguajeProgramacion;

    
    public person(long iD, String nombre, String apellido, String lenguajeDeProgramacion) {
        ID = iD;
        this.nombre = nombre;
        Apellido = apellido;
        LenguajeProgramacion = lenguajeDeProgramacion;
    }


    public long getID() {
        return ID;
    }


    public void setID(long iD) {
        ID = iD;
    }


    public String getNombre() {
        return nombre;
    }


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public String getApellido() {
        return Apellido;
    }


    public void setApellido(String apellido) {
        Apellido = apellido;
    }


    public String getLenguajeDeProgramacion() {
        return LenguajeProgramacion;
    }


    public void setLenguajeDeProgramacion(String lenguajeDeProgramacion) {
        LenguajeProgramacion = lenguajeDeProgramacion;
    }

    @Override
    public String toString(){
        return "person [ID " + ID + ", nombre=" + nombre + ", Apellido =" + Apellido + ",  LenguajesProgramacion"
        + LenguajeProgramacion + "]";
    }
    
}
