package com.dantte_011d.springboot.jpa.demo.repositories;

import org.springframework.data.repository.CrudRepository;
import com.dantte_011d.springboot.jpa.demo.person;

public interface PersonRepository extends CrudRepository<person, Long> { 



}
